# WP Flat Admin
This plugin turns a normal Wordpress admin into a mordern looking dashboard based on the Flat UI kit by Design Modo http://designmodo.com/flat

#Custom Logo
To use your own logo replace dashboard-icon.png in /images folder with a logo of your choice