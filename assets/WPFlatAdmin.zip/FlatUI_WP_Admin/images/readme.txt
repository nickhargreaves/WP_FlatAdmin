=== WP Flat Admin ===
Contributors: nickhargreaves
Tags: comments, spam
Requires at least: 3.0.1
Tested up to: 3.4
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

This plugin turns a Wordpress Admin backend into a nice looking dashboard based on the Flat UI kit by Design Modo


== Installation ==

How to install the plugin and get it working.

1. Upload the plugin folder to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. To use your own logo replace dashboard-icon.png in /images folder with a logo of your choice

Answer to foo bar dilemma.

== Screenshots ==

1. Login Screen

2. Dashboard

== Changelog ==

= 1.0 =
* Version 1